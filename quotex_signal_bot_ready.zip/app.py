from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

signals = []

@app.route('/')
def home():
    return 'Quotex Signal Bot is Running!'

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    if data:
        signals.append(data)
        return jsonify({'status': 'success', 'message': 'Signal received'}), 200
    return jsonify({'status': 'error', 'message': 'Invalid data'}), 400

@app.route('/signals', methods=['GET'])
def get_signals():
    return jsonify(signals)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)